# Final Project

- Enviroment 
    - JWT_PRIVATE_KEY
    - MAIL_SENDER
    - MAIL_KEY
- Setup
    - `npm install`
    - `npm install sequelize-cli -g`
    - `sequelize db:create`
    - `sequelize db:migrate:all`
    - `sequelize db:seed:all`
    - `npm start`
